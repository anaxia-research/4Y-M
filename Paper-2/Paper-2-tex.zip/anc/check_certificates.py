"""Exact arithmetic checks for the stated finite certificates; no YM closure claim."""
from fractions import Fraction as F
import json

x = F(1, 320)
p_upper = 1 - x + x*x/2
margin = F(160, 161) - (p_upper*p_upper + (1-p_upper)**2)
assert margin == F(32359519, 3376414720000)
assert margin > 0
assert F(3, 1000**3)/(1-F(1,1000)) == F(1,333000000)
assert F(1,333000000) < F(1,161*13824)
assert F(1683,100)*F(1,20) == F(9,10)*F(187,200)
assert F(9,10)*(1-F(9,10))/F(1683,100) == F(3,561)
rank_two = []
for p0 in (F(3, 5), F(2, 3), F(3, 4), F(9, 10), F(99, 100)):
    purity = p0*p0 + (1-p0)**2
    root = 2*p0 - 1
    assert root*root == 2*purity - 1
    d = (1-root)/(1+root)
    assert d == (1-p0)/p0
    assert purity > F(1, 2)
    rank_two.append({'top_occupation':str(p0), 'purity':str(purity), 'excited_ratio':str(d)})

kernel = []
for a,b in ((F(1), F(2)), (F(2), F(7)), (F(3, 2), F(9, 2))):
    ratio = (b-a)/(b+a)
    assert (b-a)/2 / ((b+a)/2) == ratio
    row1 = (b/(a+b), a/(a+b))
    row2 = (a/(a+b), b/(a+b))
    tv = sum(abs(s-t) for s,t in zip(row1,row2))/2
    assert tv == ratio
    mean = 2*a*b/(a+b)
    variance_ratio = (mean-a)*(b-mean)/(mean*mean)
    assert variance_ratio == (b-a)**2/(4*a*b)
    assert variance_ratio == ratio*ratio/(1-ratio*ratio)
    kernel.append({'a':str(a),'b':str(b),'spectral_ratio_and_tv':str(ratio)})

for h in (F(1, 10), F(1, 100), F(1, 1000)):
    purity_difference = 1-((1-h)**2+h*h)
    trace_distance = 2*h
    assert purity_difference/trace_distance == 1-h

print(json.dumps({
    'arithmetic':'exact Fraction arithmetic',
    'rational_pressure_margin':str(margin),
    'pressure_coefficient_improvement':str(F(320,161)),
    'rank_two_equality_cases':rank_two,
    'kernel_equality_cases':kernel,
    'gaussian_mode_budget':str(F(1,161*13824)),
    'gaussian_mode_floor_exceeds_budget':F(2,81)>F(1,161*13824),
    'actual_wilson_Haar_subcase_remainder':'1/333000000',
    'error_stable_ascent_reserve':'3/561',
    'checks_passed':True,
    'scope':'finite arithmetic only; not a uniform Wilson partition-function estimate or a Clay proof'
}, indent=2))
